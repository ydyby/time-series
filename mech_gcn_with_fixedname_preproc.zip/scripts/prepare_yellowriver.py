
"""
prepare_yellowriver.py
----------------------
Convert aligned GeoTIFF feature rasters (2000x2000, Yellow River Delta) into the .npy inputs required by mech_gcn.

Two modes:
  (A) pixel mode       : use all pixels as nodes (ONLY for small images N<=10k; 2000x2000 will OOM in graph building)
  (B) superpixel mode  : aggregate pixels into ~K superpixels (recommended; default), then treat each superpixel as one node.

Recommended: superpixel mode with n_segments ~ [3000, 10000] to keep N manageable.

USAGE
-----
python scripts/prepare_yellowriver.py --config scripts/prep_config.yaml

CONFIG (YAML)
-------------
# scripts/prep_config.yaml example
reference_tif: "/path/to/reference.tif"   # used for shape/transform/CRS alignment
out_dir: "./data/yellow_river"

inputs:
  features:                      # any number of GeoTIFFs, single-band unless specified
    - name: backscatter_vv
      path: "/path/to/vv.tif"
    - name: backscatter_vh
      path: "/path/to/vh.tif"
    - name: texture_glcm
      path: "/path/to/glcm.tif"
  H_path: "/path/to/H.tif"
  A_path: "/path/to/A.tif"
  alpha_path: "/path/to/alpha.tif"  # degrees [0,90]
  Ps_path: "/path/to/Ps.tif"
  Pd_path: "/path/to/Pd.tif"
  Pv_path: "/path/to/Pv.tif"
  gamma_path: "/path/to/gamma.tif"  # optional; if missing set to ones
  span_path: "/path/to/span.tif"    # optional unless use_esrg
  # C3/T3 matrix GeoTIFF (3x3 SPD). Provide either 9 bands (full matrix in row-major) or 6 bands (upper triangle):
  C_path: "/path/to/C3_9bands.tif"
  C_format: "9bands"    # "9bands" or "6upper"

labels:
  path: "/path/to/labels.tif"       # int class per pixel; unlabeled can be -1 or 0; set mapping below
  unlabeled_values: [-1]            # values to treat as unlabeled
  remap: {}                         # optional {old_value: new_class_id}

mode:
  use_superpixels: true
  n_segments: 6000                  # target number of superpixels (adjust to keep N<=10k)
  compactness: 10.0
  max_size_for_pixel_mode: 10000    # safety cap; if total pixels exceed and use_superpixels=false, script aborts

split:
  train: 0.6
  val: 0.2
  test: 0.2
  seed: 42

notes:
  use_esrg: false  # if true, span is required and will be used later; here we still save span.npy if provided.

OUTPUTS
-------
A folder with .npy files compatible with mech_gcn/data.py::load_dataset().
"""

import os, sys, yaml, numpy as np
from tqdm import tqdm
import rasterio
from rasterio.warp import reproject, Resampling
from rasterio.enums import Resampling as ResampleEnum
from skimage.segmentation import slic
from sklearn.model_selection import train_test_split

def read_and_align(src_path, ref_profile, ref_transform, ref_crs, nodata=None):
    with rasterio.open(src_path) as src:
        dst = np.zeros((ref_profile['height'], ref_profile['width']), dtype=np.float32)
        reproject(source=rasterio.band(src, 1),
                  destination=dst,
                  src_transform=src.transform,
                  src_crs=src.crs,
                  dst_transform=ref_transform,
                  dst_crs=ref_crs,
                  resampling=Resampling.bilinear)
        if nodata is None and src.nodata is not None:
            nodata = src.nodata
        if nodata is not None:
            dst = np.where(np.isclose(dst, nodata), np.nan, dst)
        return dst

def read_and_align_multiband(src_path, ref_profile, ref_transform, ref_crs, bands, nodata=None):
    with rasterio.open(src_path) as src:
        out = np.zeros((bands, ref_profile['height'], ref_profile['width']), dtype=np.float32)
        for b in range(1, bands+1):
            reproject(source=rasterio.band(src, b),
                      destination=out[b-1],
                      src_transform=src.transform,
                      src_crs=src.crs,
                      dst_transform=ref_transform,
                      dst_crs=ref_crs,
                      resampling=Resampling.bilinear)
        return out

def assemble_C_matrix(C_stack, C_format):
    """
    C_stack: [B,H,W] where B=9 or 6 depending on C_format.
    Returns C: [H*W, 3, 3]
    """
    H, W = C_stack.shape[1:]
    if C_format == "9bands":
        # row-major: [c11,c12,c13,c21,c22,c23,c31,c32,c33]
        C = np.stack([
            C_stack[0], C_stack[1], C_stack[2],
            C_stack[3], C_stack[4], C_stack[5],
            C_stack[6], C_stack[7], C_stack[8],
        ], axis=-1).reshape(H*W, 3, 3)
    elif C_format == "6upper":
        # upper triangle: [c11,c12,c13,c22,c23,c33]; mirror to symmetric
        c11, c12, c13, c22, c23, c33 = C_stack
        C = np.zeros((H, W, 3, 3), dtype=np.float32)
        C[...,0,0]=c11; C[...,0,1]=c12; C[...,0,2]=c13
        C[...,1,0]=c12; C[...,1,1]=c22; C[...,1,2]=c23
        C[...,2,0]=c13; C[...,2,1]=c23; C[...,2,2]=c33
        C = C.reshape(H*W,3,3)
    else:
        raise ValueError("C_format must be '9bands' or '6upper'")
    # force SPD (tiny jitter on diagonal)
    for i in range(C.shape[0]):
        C[i, range(3), range(3)] += 1e-3
    return C

def superpixel_aggregate(features_hw, label_hw, C_vec, mask_hw, n_segments=6000, compactness=10.0, seed=42):
    """
    features_hw: [H,W,F] float
    label_hw:    [H,W]   int (may contain unlabeled -1)
    C_vec:       [H*W,3,3] SPD matrices per pixel
    mask_hw:     [H,W] boolean valid mask
    Returns aggregated:
        X: [K,F], y: [K], H/A/alpha/Ps/Pd/Pv/gamma/span: [K], C: [K,3,3], mapping: [H,W] -> [0..K-1]
    """
    Hh, Ww, F = features_hw.shape
    rng = np.random.default_rng(seed)
    # Use standardized features for SLIC
    feat_std = np.copy(features_hw)
    for f in range(F):
        m = np.nanmean(feat_std[...,f])
        s = np.nanstd(feat_std[...,f]) + 1e-6
        feat_std[...,f] = np.nan_to_num((feat_std[...,f]-m)/s, nan=0.0)

    segments = slic(feat_std, n_segments=n_segments, compactness=compactness, start_label=0, convert2lab=False, channel_axis=2, enforce_connectivity=True)
    K = segments.max()+1
    # Prepare outputs
    X_list = []
    C_list = []
    y_list = []
    stats = {}  # will fill later
    # Build per-segment masks
    flat_seg = segments.reshape(-1)
    flat_mask = mask_hw.reshape(-1)
    flat_lbl = label_hw.reshape(-1)
    # Aggregate basic features (mean)
    flat_feat = features_hw.reshape(-1, F)
    for k in tqdm(range(K), desc="Aggregate superpixels"):
        idx = (flat_seg==k) & flat_mask
        if not np.any(idx):
            # empty segment (rare), fill zeros and unlabeled
            X_list.append(np.zeros((F,), dtype=np.float32))
            C_list.append(np.eye(3, dtype=np.float32))
            y_list.append(-1)
            continue
        X_list.append(np.nanmean(flat_feat[idx], axis=0).astype(np.float32))
        # C aggregate
        C_list.append(np.nanmean(C_vec[idx], axis=0).astype(np.float32))
        # label: majority vote among labeled pixels
        lbl_valid = flat_lbl[idx]
        lbl_valid = lbl_valid[lbl_valid>=0]
        if lbl_valid.size==0:
            y_list.append(-1)
        else:
            vals, counts = np.unique(lbl_valid, return_counts=True)
            y_list.append(int(vals[np.argmax(counts)]))
    X = np.stack(X_list, axis=0)
    C = np.stack(C_list, axis=0)
    y = np.array(y_list, dtype=np.int64)
    return X, C, y, segments

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    out_dir = cfg["out_dir"]
    os.makedirs(out_dir, exist_ok=True)

    # Read reference raster
    ref_path = cfg["reference_tif"]
    with rasterio.open(ref_path) as ref:
        ref_profile = ref.profile
        ref_transform = ref.transform
        ref_crs = ref.crs
        Hh, Ww = ref.height, ref.width

    # ----- Read base features list
    feat_defs = cfg["inputs"]["features"]
    feat_arrays = []
    for item in feat_defs:
        arr = read_and_align(item["path"], ref_profile, ref_transform, ref_crs)
        feat_arrays.append(arr)
    # Read H/A/alpha/Ps/Pd/Pv/gamma/span
    H_arr     = read_and_align(cfg["inputs"]["H_path"],     ref_profile, ref_transform, ref_crs)
    A_arr     = read_and_align(cfg["inputs"]["A_path"],     ref_profile, ref_transform, ref_crs)
    alpha_arr = read_and_align(cfg["inputs"]["alpha_path"], ref_profile, ref_transform, ref_crs)
    Ps_arr    = read_and_align(cfg["inputs"]["Ps_path"],    ref_profile, ref_transform, ref_crs)
    Pd_arr    = read_and_align(cfg["inputs"]["Pd_path"],    ref_profile, ref_transform, ref_crs)
    Pv_arr    = read_and_align(cfg["inputs"]["Pv_path"],    ref_profile, ref_transform, ref_crs)

    gamma_arr = None
    if "gamma_path" in cfg["inputs"] and cfg["inputs"]["gamma_path"]:
        gamma_arr = read_and_align(cfg["inputs"]["gamma_path"], ref_profile, ref_transform, ref_crs)
    else:
        gamma_arr = np.ones((Hh,Ww), dtype=np.float32)

    span_arr = None
    if "span_path" in cfg["inputs"] and cfg["inputs"]["span_path"]:
        span_arr = read_and_align(cfg["inputs"]["span_path"], ref_profile, ref_transform, ref_crs)
    else:
        span_arr = np.ones((Hh,Ww), dtype=np.float32)

    # C matrix
    C_stack = None
    C_path = cfg["inputs"]["C_path"]
    C_format = cfg["inputs"].get("C_format", "9bands")
    if C_path and C_format == "9bands":
        with rasterio.open(C_path) as src:
            C_stack = np.zeros((9, Hh, Ww), dtype=np.float32)
            for b in range(1, 10):
                reproject(source=rasterio.band(src, b),
                          destination=C_stack[b-1],
                          src_transform=src.transform, src_crs=src.crs,
                          dst_transform=ref_transform, dst_crs=ref_crs,
                          resampling=Resampling.bilinear)
    elif C_path and C_format == "6upper":
        with rasterio.open(C_path) as src:
            C_stack = np.zeros((6, Hh, Ww), dtype=np.float32)
            for b in range(1, 7):
                reproject(source=rasterio.band(src, b),
                          destination=C_stack[b-1],
                          src_transform=src.transform, src_crs=src.crs,
                          dst_transform=ref_transform, dst_crs=ref_crs,
                          resampling=Resampling.bilinear)
    else:
        raise ValueError("C_path must be specified with C_format in {9bands,6upper}")

    C_vec = assemble_C_matrix(C_stack, C_format)  # [H*W,3,3]

    # Label
    with rasterio.open(cfg["labels"]["path"]) as labsrc:
        labels_hw = np.zeros((Hh,Ww), dtype=np.float32)
        reproject(source=rasterio.band(labsrc, 1),
                  destination=labels_hw,
                  src_transform=labsrc.transform, src_crs=labsrc.crs,
                  dst_transform=ref_transform, dst_crs=ref_crs,
                  resampling=Resampling.nearest)
    labels_hw = labels_hw.astype(np.int64)
    # remap & unlabeled
    remap = cfg["labels"].get("remap", {}) or {}
    if len(remap)>0:
        # remap dict keys may be strings
        rkeys = list(remap.keys())
        for k in rkeys:
            old = int(k)
            new = int(remap[k])
            labels_hw[labels_hw==old] = new
    unlabeled_values = cfg["labels"].get("unlabeled_values", [-1])
    mask_labeled = np.ones_like(labels_hw, dtype=bool)
    for uv in unlabeled_values:
        mask_labeled &= (labels_hw != uv)
    # VALID MASK: all features finite
    F_extra = [H_arr, A_arr, alpha_arr, Ps_arr, Pd_arr, Pv_arr, gamma_arr, span_arr]
    feat_arrays_all = feat_arrays + F_extra
    valid_mask = np.ones((Hh,Ww), dtype=bool)
    for arr in feat_arrays_all:
        valid_mask &= np.isfinite(arr)
    # Combine into feature cube HxW x F
    feature_stack = np.stack(feat_arrays + [H_arr, A_arr, alpha_arr, Ps_arr, Pd_arr, Pv_arr, gamma_arr, span_arr], axis=-1)  # [H,W,F]
    # Extract named indices for required arrays in mech_gcn
    # We will later split them back out by index when saving .npy

    # Mode decision
    use_superpixels = bool(cfg["mode"].get("use_superpixels", True))
    if not use_superpixels:
        total = Hh*Ww
        if total > int(cfg["mode"].get("max_size_for_pixel_mode", 10000)):
            raise RuntimeError(f"Pixel mode would create {total} nodes which is too large for dense affinity. Enable superpixels.")
        # Pixel mode (NOT recommended for large rasters)
        X = feature_stack.reshape(-1, feature_stack.shape[-1]).astype(np.float32)
        C = C_vec.astype(np.float32)
        y = labels_hw.reshape(-1).astype(np.int64)
        # train/val/test split on labeled indices only
        labeled_idx = np.where(y>=0)[0]
        y_labeled = y[labeled_idx]
        train_ratio = float(cfg["split"]["train"])
        val_ratio   = float(cfg["split"]["val"])
        test_ratio  = float(cfg["split"]["test"])
        seed        = int(cfg["split"]["seed"])
        Xtr, Xte, ytr, yte, idx_tr, idx_te = train_test_split(np.zeros_like(y_labeled), y_labeled, labeled_idx,
                                                              test_size=test_ratio, random_state=seed, stratify=y_labeled)
        val_size = val_ratio / (train_ratio + val_ratio)
        Xtr2, Xva, ytr2, yva, idx_tr2, idx_va = train_test_split(np.zeros_like(ytr), ytr, idx_tr,
                                                                 test_size=val_size, random_state=seed, stratify=ytr)
        train_idx = idx_tr2; val_idx = idx_va; test_idx = idx_te
    else:
        # Superpixel mode
        n_segments = int(cfg["mode"].get("n_segments", 6000))
        compactness = float(cfg["mode"].get("compactness", 10.0))
        X_all, C_all, y_all, segmap = superpixel_aggregate(feature_stack, labels_hw, C_vec, valid_mask,
                                                           n_segments=n_segments, compactness=compactness, seed=int(cfg["split"]["seed"]))
        # Split labeled superpixels
        labeled_nodes = np.where(y_all>=0)[0]
        y_lab = y_all[labeled_nodes]
        train_ratio = float(cfg["split"]["train"])
        val_ratio   = float(cfg["split"]["val"])
        test_ratio  = float(cfg["split"]["test"])
        seed        = int(cfg["split"]["seed"])
        dummy = np.zeros_like(y_lab)
        _, _, _, _, idx_tr, idx_te = train_test_split(dummy, y_lab, labeled_nodes,
                                                      test_size=test_ratio, random_state=seed, stratify=y_lab)
        val_size = val_ratio / (train_ratio + val_ratio)
        _, _, _, _, idx_tr2, idx_va = train_test_split(dummy[idx_tr - labeled_nodes.min()], y_all[idx_tr],
                                                       idx_tr, test_size=val_size, random_state=seed, stratify=y_all[idx_tr])
        train_idx = idx_tr2; val_idx = idx_va; test_idx = idx_te

        # Now split back mech_gcn required arrays from X_all columns.
        # We assumed feature_stack order: [user_features..., H, A, alpha, Ps, Pd, Pv, gamma, span]
        F_user = len(feat_arrays)
        H_vec = X_all[:, F_user + 0]
        A_vec = X_all[:, F_user + 1]
        alpha_vec = X_all[:, F_user + 2]
        Ps_vec = X_all[:, F_user + 3]
        Pd_vec = X_all[:, F_user + 4]
        Pv_vec = X_all[:, F_user + 5]
        gamma_vec = X_all[:, F_user + 6]
        span_vec  = X_all[:, F_user + 7]

        X = X_all[:, :F_user]  # only user features as 'features.npy'
        H = H_vec; A = A_vec; alpha = alpha_vec
        Ps = Ps_vec; Pd = Pd_vec; Pv = Pv_vec
        gamma = gamma_vec; span = span_vec
        C = C_all; y = y_all

    # Save .npy files
    np.save(os.path.join(out_dir, "features.npy"), X.astype(np.float32))
    np.save(os.path.join(out_dir, "labels.npy"),   y.astype(np.int64))
    if use_superpixels:
        np.save(os.path.join(out_dir, "H.npy"),       H.astype(np.float32))
        np.save(os.path.join(out_dir, "A.npy"),       A.astype(np.float32))
        np.save(os.path.join(out_dir, "alpha.npy"),   alpha.astype(np.float32))
        np.save(os.path.join(out_dir, "Ps.npy"),      Ps.astype(np.float32))
        np.save(os.path.join(out_dir, "Pd.npy"),      Pd.astype(np.float32))
        np.save(os.path.join(out_dir, "Pv.npy"),      Pv.astype(np.float32))
        np.save(os.path.join(out_dir, "gamma.npy"),   gamma.astype(np.float32))
        np.save(os.path.join(out_dir, "span.npy"),    span.astype(np.float32))
    else:
        # In pixel mode, those are available inside X's last channels; but save empty proxies
        pass
    np.save(os.path.join(out_dir, "C.npy"),         C.astype(np.float32))
    np.save(os.path.join(out_dir, "train_idx.npy"), np.array(train_idx, dtype=np.int64))
    np.save(os.path.join(out_dir, "val_idx.npy"),   np.array(val_idx, dtype=np.int64))
    np.save(os.path.join(out_dir, "test_idx.npy"),  np.array(test_idx, dtype=np.int64))

    print(f"Saved .npy files to {out_dir}")
    print(f"N nodes: {X.shape[0]} | F (user features): {X.shape[1]}")

if __name__ == "__main__":
    main()
