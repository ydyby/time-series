
"""
prepare_from_fixed_names.py
---------------------------
Preprocess Yellow River Delta rasters using the *fixed file names you provided*.

Expected files inside --input_dir:
  A.tif                (anisotropy, i.e., A in H/alpha/A)
  alpha.tif            (alpha angle, degrees 0..90)
  H.tif                (entropy H in [0,1])
  gamma.tif            (coherence 0..1)
  span.tif             (total power)
  VV.tif, VH.tif       (backscatter; optional but recommended as user features)
  zhenzhi.tif          (labels; int; unlabeled set later in args)
  # Complex C3 components (Hermitian):
  C11.tif, C22.tif, C33.tif                      (real, non-negative)
  C12_real.tif, C12_imag.tif
  C13_real.tif, C13_imag.tif
  C23_real.tif, C23_imag.tif
  # Yamaguchi decomposition (3 used here)
  Y_odd.tif (surface-like), Y_dbl.tif (double-bounce), Y_vol.tif (volume)

This script converts these into the mech_gcn .npy inputs.
It supports two strategies to derive a real SPD 3x3 matrix from complex C3:
  --complex_to_real {magnitude,real}  (default: magnitude)
    - magnitude: off-diagonal Cij := sqrt(Re^2 + Im^2); diagonal Cii as-is.
    - real     : off-diagonal Cij := Re(Cij).

Both add a tiny jitter on the diagonal to stabilize SPD (not guaranteed mathematically, but practical).

USAGE
-----
python scripts/prepare_from_fixed_names.py \
  --input_dir ./data/raw \
  --out_dir ./data/yellow_river \
  --reference VV.tif \
  --use_superpixels \
  --n_segments 6000 \
  --compactness 10.0 \
  --unlabeled_values -1 \
  --split 0.6 0.2 0.2 \
  --complex_to_real magnitude

Requires: rasterio, scikit-image, scikit-learn, numpy, tqdm
"""

import os, sys, argparse, numpy as np
import rasterio
from rasterio.warp import reproject, Resampling
from tqdm import tqdm
from skimage.segmentation import slic
from sklearn.model_selection import train_test_split

FILES = [
    "A.tif", "alpha.tif", "H.tif", "gamma.tif", "span.tif",
    "VV.tif", "VH.tif",
    "zhenzhi.tif",
    "C11.tif","C22.tif","C33.tif",
    "C12_real.tif","C12_imag.tif",
    "C13_real.tif","C13_imag.tif",
    "C23_real.tif","C23_imag.tif",
    "Y_odd.tif","Y_dbl.tif","Y_vol.tif"
]

def open_ref(ref_path_full):
    with rasterio.open(ref_path_full) as ref:
        profile = ref.profile
        return profile, ref.transform, ref.crs

def reproj_to_ref(src_path, ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear):
    with rasterio.open(src_path) as src:
        dst = np.zeros((ref_profile['height'], ref_profile['width']), dtype=np.float32)
        reproject(
            source=rasterio.band(src, 1),
            destination=dst,
            src_transform=src.transform, src_crs=src.crs,
            dst_transform=ref_transform, dst_crs=ref_crs,
            resampling=resampling
        )
        # nodata handling (optional): if src.nodata present, map to NaN
        if src.nodata is not None:
            nd = src.nodata
            dst = np.where(np.isclose(dst, nd), np.nan, dst)
        return dst

def build_C_real(input_dir, ref_profile, ref_transform, ref_crs, strategy="magnitude"):
    C11 = reproj_to_ref(os.path.join(input_dir,"C11.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C22 = reproj_to_ref(os.path.join(input_dir,"C22.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C33 = reproj_to_ref(os.path.join(input_dir,"C33.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C12r = reproj_to_ref(os.path.join(input_dir,"C12_real.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C12i = reproj_to_ref(os.path.join(input_dir,"C12_imag.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C13r = reproj_to_ref(os.path.join(input_dir,"C13_real.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C13i = reproj_to_ref(os.path.join(input_dir,"C13_imag.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C23r = reproj_to_ref(os.path.join(input_dir,"C23_real.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)
    C23i = reproj_to_ref(os.path.join(input_dir,"C23_imag.tif"), ref_profile, ref_transform, ref_crs, resampling=Resampling.bilinear)

    if strategy == "magnitude":
        C12 = np.sqrt(C12r**2 + C12i**2)
        C13 = np.sqrt(C13r**2 + C13i**2)
        C23 = np.sqrt(C23r**2 + C23i**2)
    elif strategy == "real":
        C12 = C12r; C13 = C13r; C23 = C23r
    else:
        raise ValueError("strategy must be 'magnitude' or 'real'")

    Hh, Ww = C11.shape
    C = np.zeros((Hh, Ww, 3, 3), dtype=np.float32)
    C[...,0,0] = C11
    C[...,1,1] = C22
    C[...,2,2] = C33
    C[...,0,1] = C[...,1,0] = C12
    C[...,0,2] = C[...,2,0] = C13
    C[...,1,2] = C[...,2,1] = C23

    # tiny jitter to encourage SPD
    C[...,0,0] += 1e-3
    C[...,1,1] += 1e-3
    C[...,2,2] += 1e-3

    return C.reshape(-1,3,3)

def superpixel_aggregate(feat_hw, label_hw, C_vec, valid_mask, n_segments=6000, compactness=10.0, seed=42):
    Hh, Ww, F = feat_hw.shape
    # normalize features for SLIC stability
    feat_std = np.copy(feat_hw)
    for f in range(F):
        m = np.nanmean(feat_std[...,f])
        s = np.nanstd(feat_std[...,f]) + 1e-6
        feat_std[...,f] = np.nan_to_num((feat_std[...,f]-m)/s, nan=0.0)
    segments = slic(feat_std, n_segments=n_segments, compactness=compactness,
                    start_label=0, convert2lab=False, channel_axis=2, enforce_connectivity=True)
    K = segments.max()+1
    flat_seg = segments.reshape(-1)
    flat_mask = valid_mask.reshape(-1)
    flat_lbl = label_hw.reshape(-1)
    flat_feat = feat_hw.reshape(-1, F)
    X_list, C_list, y_list = [], [], []
    for k in tqdm(range(K), desc="Aggregate superpixels"):
        idx = (flat_seg==k) & flat_mask
        if not np.any(idx):
            X_list.append(np.zeros((F,), dtype=np.float32))
            C_list.append(np.eye(3, dtype=np.float32))
            y_list.append(-1)
            continue
        X_list.append(np.nanmean(flat_feat[idx], axis=0).astype(np.float32))
        C_list.append(np.nanmean(C_vec[idx], axis=0).astype(np.float32))
        lbl = flat_lbl[idx]
        lbl = lbl[lbl>=0]
        if lbl.size==0:
            y_list.append(-1)
        else:
            vals, counts = np.unique(lbl, return_counts=True)
            y_list.append(int(vals[np.argmax(counts)]))
    X = np.stack(X_list, axis=0)
    C = np.stack(C_list, axis=0)
    y = np.array(y_list, dtype=np.int64)
    return X, C, y, segments

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_dir", required=True, help="Folder containing the fixed-named .tif files")
    ap.add_argument("--out_dir", required=True, help="Output folder for .npy files")
    ap.add_argument("--reference", default="VV.tif", help="Which raster inside input_dir to use as reference grid (e.g., VV.tif)")
    ap.add_argument("--use_superpixels", action="store_true")
    ap.add_argument("--n_segments", type=int, default=6000)
    ap.add_argument("--compactness", type=float, default=10.0)
    ap.add_argument("--unlabeled_values", type=int, nargs="+", default=[-1])
    ap.add_argument("--split", type=float, nargs=3, default=[0.6,0.2,0.2])
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--complex_to_real", choices=["magnitude","real"], default="magnitude")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    for fn in ["A.tif","alpha.tif","H.tif","gamma.tif","span.tif","VV.tif","VH.tif","zhenzhi.tif"]:
        if not os.path.exists(os.path.join(args.input_dir, fn)):
            raise FileNotFoundError(f"Missing required file: {fn} in {args.input_dir}")

    ref_path_full = os.path.join(args.input_dir, args.reference)
    ref_profile, ref_transform, ref_crs = open_ref(ref_path_full)

    # Load rasters aligned to reference
    def read(name, resampling=Resampling.bilinear):
        return reproj_to_ref(os.path.join(args.input_dir, name), ref_profile, ref_transform, ref_crs, resampling=resampling)

    A_arr     = read("A.tif")
    alpha_arr = read("alpha.tif")
    H_arr     = read("H.tif")
    gamma_arr = read("gamma.tif")
    span_arr  = read("span.tif")
    VV_arr    = read("VV.tif")
    VH_arr    = read("VH.tif")
    labels_hw = read("zhenzhi.tif", resampling=Resampling.nearest).astype(np.int64)

    # Yamaguchi -> map to Ps/Pd/Pv (odd/surface, dbl/double-bounce, vol/volume)
    Ps_arr = read("Y_odd.tif")
    Pd_arr = read("Y_dbl.tif")
    Pv_arr = read("Y_vol.tif")

    # Build C (3x3 real) from complex components
    C_vec = build_C_real(args.input_dir, ref_profile, ref_transform, ref_crs, strategy=args.complex_to_real)

    # Valid mask: must be finite across all feature rasters we will use
    feat_list = [VV_arr, VH_arr, H_arr, A_arr, alpha_arr, Ps_arr, Pd_arr, Pv_arr, gamma_arr, span_arr]
    valid_mask = np.ones_like(H_arr, dtype=bool)
    for arr in feat_list:
        valid_mask &= np.isfinite(arr)

    # Feature stack: user features (VV, VH) first; then H,A,alpha, Ps,Pd,Pv, gamma, span
    features_hw = np.stack([VV_arr, VH_arr], axis=-1)  # user-visible features
    extra_hw = np.stack([H_arr, A_arr, alpha_arr, Ps_arr, Pd_arr, Pv_arr, gamma_arr, span_arr], axis=-1)
    full_hw = np.concatenate([features_hw, extra_hw], axis=-1)

    # Handle unlabeled values
    mask_labeled = np.ones_like(labels_hw, dtype=bool)
    for uv in args.unlabeled_values:
        mask_labeled &= (labels_hw != uv)
    # (no direct change to labels; unlabeled=-1 expected by training; if not -1, map them now)
    for uv in args.unlabeled_values:
        labels_hw[labels_hw == uv] = -1

    if args.use_superpixels:
        X_all, C_all, y_all, seg = superpixel_aggregate(full_hw, labels_hw, C_vec, valid_mask,
                                                        n_segments=args.n_segments, compactness=args.compactness, seed=args.seed)
        # Split labeled nodes stratified
        labeled_nodes = np.where(y_all>=0)[0]
        y_lab = y_all[labeled_nodes]
        tr, va, te = args.split
        dummy = np.zeros_like(y_lab)
        _, _, _, _, idx_tr, idx_te = train_test_split(dummy, y_lab, labeled_nodes,
                                                      test_size=te, random_state=args.seed, stratify=y_lab)
        val_size = va / (tr + va)
        _, _, _, _, idx_tr2, idx_va = train_test_split(dummy[idx_tr - labeled_nodes.min()], y_all[idx_tr],
                                                       idx_tr, test_size=val_size, random_state=args.seed, stratify=y_all[idx_tr])

        # split back arrays
        F_user = 2  # VV, VH
        H_vec     = X_all[:, F_user + 0]
        A_vec     = X_all[:, F_user + 1]
        alpha_vec = X_all[:, F_user + 2]
        Ps_vec    = X_all[:, F_user + 3]
        Pd_vec    = X_all[:, F_user + 4]
        Pv_vec    = X_all[:, F_user + 5]
        gamma_vec = X_all[:, F_user + 6]
        span_vec  = X_all[:, F_user + 7]

        X = X_all[:, :F_user]
        H = H_vec; A = A_vec; alpha = alpha_vec
        Ps = Ps_vec; Pd = Pd_vec; Pv = Pv_vec
        gamma = gamma_vec; span = span_vec
        C = C_all; y = y_all
        train_idx = idx_tr2; val_idx = idx_va; test_idx = idx_te
    else:
        # Pixel mode (only for tiny images)
        Hh, Ww, F = full_hw.shape
        X = full_hw.reshape(-1, full_hw.shape[-1]).astype(np.float32)
        C = C_vec.astype(np.float32)
        y = labels_hw.reshape(-1).astype(np.int64)
        labeled_idx = np.where(y>=0)[0]
        y_lab = y[labeled_idx]
        tr, va, te = args.split
        dummy = np.zeros_like(y_lab)
        _, _, _, _, idx_tr, idx_te = train_test_split(dummy, y_lab, labeled_idx,
                                                      test_size=te, random_state=args.seed, stratify=y_lab)
        val_size = va / (tr + va)
        _, _, _, _, idx_tr2, idx_va = train_test_split(dummy[idx_tr - labeled_idx.min()], y[idx_tr],
                                                       idx_tr, test_size=val_size, random_state=args.seed, stratify=y[idx_tr])
        train_idx = idx_tr2; val_idx = idx_va; test_idx = idx_te

        # Split fields
        F_user = 2
        H = X[:, F_user + 0]; A = X[:, F_user + 1]; alpha = X[:, F_user + 2]
        Ps = X[:, F_user + 3]; Pd = X[:, F_user + 4]; Pv = X[:, F_user + 5]
        gamma = X[:, F_user + 6]; span = X[:, F_user + 7]
        X = X[:, :F_user]

    # Save outputs
    np.save(os.path.join(args.out_dir, "features.npy"), X.astype(np.float32))
    np.save(os.path.join(args.out_dir, "labels.npy"),   y.astype(np.int64))
    np.save(os.path.join(args.out_dir, "H.npy"),        H.astype(np.float32))
    np.save(os.path.join(args.out_dir, "A.npy"),        A.astype(np.float32))
    np.save(os.path.join(args.out_dir, "alpha.npy"),    alpha.astype(np.float32))
    np.save(os.path.join(args.out_dir, "Ps.npy"),       Ps.astype(np.float32))
    np.save(os.path.join(args.out_dir, "Pd.npy"),       Pd.astype(np.float32))
    np.save(os.path.join(args.out_dir, "Pv.npy"),       Pv.astype(np.float32))
    np.save(os.path.join(args.out_dir, "gamma.npy"),    gamma.astype(np.float32))
    np.save(os.path.join(args.out_dir, "span.npy"),     span.astype(np.float32))
    np.save(os.path.join(args.out_dir, "C.npy"),        C.astype(np.float32))
    np.save(os.path.join(args.out_dir, "train_idx.npy"), np.array(train_idx, dtype=np.int64))
    np.save(os.path.join(args.out_dir, "val_idx.npy"),   np.array(val_idx, dtype=np.int64))
    np.save(os.path.join(args.out_dir, "test_idx.npy"),  np.array(test_idx, dtype=np.int64))

    print(f"Done. Saved arrays to {args.out_dir}. N={X.shape[0]}, F={X.shape[1]} (user features: VV,VH).")

if __name__ == "__main__":
    main()
