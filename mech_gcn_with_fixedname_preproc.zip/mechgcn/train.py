import os, argparse, yaml, numpy as np, torch
import torch.nn.functional as F
from torch import optim
from tqdm import tqdm

from .data import load_dataset
from .graph import MechanismGraphBuilder
from .models import SimpleRGCN
from .utils import set_seed, accuracy_score, confusion_matrix_and_iou, f1_per_class

def mech_laplacian_reg(Z, A_list, coef=1e-3):
    """
    Z: [N, D] embedding
    A_list: list of dense affinity matrices [N,N] (torch.float32)
    """
    loss = 0.0
    for A in A_list:
        D = torch.diag(A.sum(dim=1))
        L = D - A
        loss = loss + torch.trace(Z.T @ L @ Z)
    return coef * loss

def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def main(args):
    cfg = load_config(args.config)
    set_seed(cfg["train"]["seed"])

    device = "cuda" if torch.cuda.is_available() else "cpu"
    data_dir = cfg["data_dir"]

    # === Data ===
    need_esrg = bool(cfg["graph"].get("use_esrg", False))
    data = load_dataset(data_dir, need_esrg=need_esrg)
    X = torch.from_numpy(data["X"]).to(device)
    y = torch.from_numpy(data["y"]).to(device)
    H = torch.from_numpy(data["H"]).to(device)
    A = torch.from_numpy(data["A"]).to(device)
    alpha = torch.from_numpy(data["alpha"]).to(device)
    C = torch.from_numpy(data["C"]).to(device)
    Ps = torch.from_numpy(data["Ps"]).to(device)
    Pd = torch.from_numpy(data["Pd"]).to(device)
    Pv = torch.from_numpy(data["Pv"]).to(device)
    gamma = torch.from_numpy(data["gamma"]).to(device)
    span = torch.from_numpy(data["span"]).to(device)

    train_idx = torch.from_numpy(data["train_idx"]).long().to(device)
    val_idx   = torch.from_numpy(data["val_idx"]).long().to(device)
    test_idx  = torch.from_numpy(data["test_idx"]).long().to(device)

    num_nodes, in_dim = X.shape
    num_classes = cfg["model"]["num_classes"]

    # === Graph builder ===
    gb = MechanismGraphBuilder(
        use_pme=cfg["graph"]["use_pme"],
        use_spd=cfg["graph"]["use_spd"],
        spd_sigma=float(cfg["graph"]["spd_sigma"]),
        spd_lambda=float(cfg["graph"]["spd_lambda"]),
        use_coherence_gate=cfg["graph"]["use_coherence_gate"],
        coherence_beta=float(cfg["graph"]["coherence_beta"]),
        use_esrg=cfg["graph"]["use_esrg"],
        esrg_a0=float(cfg["graph"]["esrg_a0"]),
        esrg_a1=float(cfg["graph"]["esrg_a1"]),
        esrg_a2=float(cfg["graph"]["esrg_a2"]),
        k=int(cfg["graph"]["k"]),
        mechanism_adaptive_k=cfg["graph"]["mechanism_adaptive_k"],
        build_bidirectional=cfg["graph"]["build_bidirectional"],
        device=device
    ).to(device)

    # === Model ===
    model = SimpleRGCN(in_dim=in_dim, hidden_dim=cfg["model"]["hidden_dim"], num_classes=num_classes).to(device)
    params = list(model.parameters()) + list(gb.parameters())
    optimizer = optim.Adam(params, lr=float(cfg["train"]["lr"]), weight_decay=float(cfg["train"]["weight_decay"]))

    os.makedirs("./checkpoints", exist_ok=True)
    best_val_miou = -1.0
    best_ckpt = os.path.join("./checkpoints", "best.pt")

    for epoch in range(1, int(cfg["train"]["epochs"]) + 1):
        model.train()
        (g_s, g_d, g_v), A_dict = gb(H, A, alpha, C, Ps, Pd, Pv, gamma, span)
        logits, Z = model([g_s, g_d, g_v], X)

        loss_cls = F.cross_entropy(logits[train_idx], y[train_idx])
        loss_reg = mech_laplacian_reg(Z, [A_dict["Ws"], A_dict["Wd"], A_dict["Wv"]], coef=float(cfg["train"]["mech_lap_coef"]))
        loss = loss_cls + loss_reg

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if epoch % int(cfg["train"]["eval_every"]) == 0 or epoch == 1:
            model.eval()
            with torch.no_grad():
                (g_s, g_d, g_v), _ = gb(H, A, alpha, C, Ps, Pd, Pv, gamma, span)
                logits, Z = model([g_s, g_d, g_v], X)
                pred = logits.argmax(dim=1)

                oa_tr = accuracy_score(y[train_idx].detach().cpu().numpy(), pred[train_idx].detach().cpu().numpy())
                oa_va = accuracy_score(y[val_idx].detach().cpu().numpy(),   pred[val_idx].detach().cpu().numpy())
                _, _, miou_va = confusion_matrix_and_iou(y[val_idx].detach().cpu().numpy(),
                                                         pred[val_idx].detach().cpu().numpy(),
                                                         num_classes)
                print(f"[Epoch {epoch:03d}] loss={loss.item():.4f}  OA_train={oa_tr:.4f}  OA_val={oa_va:.4f}  mIoU_val={miou_va:.4f}")

                if miou_va > best_val_miou:
                    best_val_miou = miou_va
                    torch.save({
                        "epoch": epoch,
                        "model_state": model.state_dict(),
                        "gb_state": gb.state_dict(),
                        "cfg": cfg
                    }, best_ckpt)
                    print(f"  -> Saved best checkpoint to {best_ckpt} (mIoU_val={best_val_miou:.4f})")

    # Final test
    print("== Evaluate best checkpoint on TEST set ==")
    ckpt = torch.load(best_ckpt, map_location=device)
    model.load_state_dict(ckpt["model_state"])
    gb.load_state_dict(ckpt["gb_state"])
    model.eval()
    with torch.no_grad():
        (g_s, g_d, g_v), _ = gb(H, A, alpha, C, Ps, Pd, Pv, gamma, span)
        logits, Z = model([g_s, g_d, g_v], X)
        pred = logits.argmax(dim=1)

        oa_te = accuracy_score(y[test_idx].detach().cpu().numpy(), pred[test_idx].detach().cpu().numpy())
        cm, iou, miou_te = confusion_matrix_and_iou(y[test_idx].detach().cpu().numpy(),
                                                    pred[test_idx].detach().cpu().numpy(),
                                                    num_classes)
        f1 = f1_per_class(y[test_idx].detach().cpu().numpy(),
                          pred[test_idx].detach().cpu().numpy(), num_classes)
        print(f"OA_test={oa_te:.4f}  mIoU_test={miou_te:.4f}")
        print("Per-class IoU:", [f"{v:.3f}" for v in iou])
        print("Per-class F1 :", [f"{v:.3f}" for v in f1])

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="config.yaml")
    args = parser.parse_args()
    main(args)
