import torch, torch.nn as nn, torch.nn.functional as F
import dgl
import numpy as np

def pairwise_abs_diff(v: torch.Tensor):
    # v: [N], returns [N,N] of |vi - vj|
    return torch.abs(v[:, None] - v[None, :])

class PMEEdge(nn.Module):
    """
    Physics-Monotone Edge on H, alpha, A:
    w_ij = exp( - (λ1*|Δα| + λ2*|ΔH| + λ3*|ΔA|) / τ )
    """
    def __init__(self, init_lams=(1.0,1.0,1.0), init_tau=0.2):
        super().__init__()
        self.lam_alpha = nn.Parameter(torch.tensor([init_lams[0]], dtype=torch.float32))
        self.lam_H     = nn.Parameter(torch.tensor([init_lams[1]], dtype=torch.float32))
        self.lam_A     = nn.Parameter(torch.tensor([init_lams[2]], dtype=torch.float32))
        self.tau       = nn.Parameter(torch.tensor([init_tau], dtype=torch.float32))

    def forward(self, H, A, alpha):
        d_alpha = pairwise_abs_diff(alpha)
        d_H     = pairwise_abs_diff(H)
        d_A     = pairwise_abs_diff(A)
        lam_alpha = F.softplus(self.lam_alpha) + 1e-6
        lam_H     = F.softplus(self.lam_H)     + 1e-6
        lam_A     = F.softplus(self.lam_A)     + 1e-6
        tau       = F.softplus(self.tau)       + 1e-6
        d = lam_alpha * d_alpha + lam_H * d_H + lam_A * d_A
        W = torch.exp(- d / tau)
        W.fill_diagonal_(0.0)
        return W

def spd_logm(C: torch.Tensor):
    # C: [N,3,3], symmetric positive-definite
    s, U = torch.linalg.eigh(C)      # s: [N,3], U: [N,3,3]
    s = torch.clamp(s, min=1e-8)
    log_s = torch.log(s)
    logC = U @ torch.diag_embed(log_s) @ U.transpose(-1,-2)
    return logC

def spd_log_euclidean_affinity(C: torch.Tensor, sigma: float = 1.0):
    # W_ij = exp( -||logC_i - logC_j||_F^2 / sigma^2 )
    logC = spd_logm(C)          # [N,3,3]
    N = logC.size(0)
    L = logC.reshape(N, -1)     # [N,9]
    norm2 = (L*L).sum(dim=1, keepdim=True)  # [N,1]
    d2 = norm2 + norm2.T - 2.0*(L @ L.T)
    W = torch.exp(- d2 / (sigma**2 + 1e-8))
    W.fill_diagonal_(0.0)
    return W

def apply_coherence_gate(W: torch.Tensor, gamma: torch.Tensor, beta: float = 1.0):
    # gamma: [N] in [0,1]
    g_ij = torch.minimum(gamma[:, None], gamma[None, :]) ** beta
    Wg = W * g_ij
    Wg.fill_diagonal_(0.0)
    return Wg

def mechanism_masks(Ps, Pd, Pv, eps=1e-6):
    Psum = Ps + Pd + Pv + eps
    ps = Ps / Psum; pd = Pd / Psum; pv = Pv / Psum
    mech = torch.stack([ps, pd, pv], dim=1)  # [N,3]
    winner = mech.argmax(dim=1)              # 0:surface,1:double,2:volume
    Ms = (winner == 0).float()
    Md = (winner == 1).float()
    Mv = (winner == 2).float()
    return Ms, Md, Mv

def masked_affinity(W: torch.Tensor, M: torch.Tensor):
    return W * (M[:, None] * M[None, :])

def topk_edges_from_affinity(W: torch.Tensor, k: int, bidirectional=True):
    N = W.size(0)
    W = W.clone()
    W.fill_diagonal_(0.0)
    vals, idx = torch.topk(W, k=k, dim=1)  # [N,k]
    src = torch.arange(N, device=W.device).repeat_interleave(k)   # [N*k]
    dst = idx.reshape(-1)                                         # [N*k]
    w = vals.reshape(-1)
    if bidirectional:
        src2 = dst; dst2 = src; w2 = w
        src = torch.cat([src, src2], dim=0)
        dst = torch.cat([dst, dst2], dim=0)
        w   = torch.cat([w,   w2  ], dim=0)
    edge_index = torch.stack([src, dst], dim=0)
    return edge_index, w

def build_dgl_graph(edge_index, edge_weight, num_nodes):
    g = dgl.graph((edge_index[0], edge_index[1]), num_nodes=num_nodes)
    g = dgl.to_simple(g, return_counts=None)  # remove multiedges
    g.edata['w'] = edge_weight[:g.num_edges()]  # truncate if reduced
    return g

class ESRG(nn.Module):
    def __init__(self, a0=0.0, a1=1.0, a2=0.5):
        super().__init__()
        self.a0 = nn.Parameter(torch.tensor([a0], dtype=torch.float32))
        self.a1 = nn.Parameter(torch.tensor([a1], dtype=torch.float32))
        self.a2 = nn.Parameter(torch.tensor([a2], dtype=torch.float32))
    def forward(self, W, H, span):
        r = torch.sigmoid(self.a0 + self.a1*(1.0 - H) + self.a2*torch.log(span + 1e-6))  # [N]
        R = torch.minimum(r[:, None], r[None, :])
        Wg = W * R
        Wg.fill_diagonal_(0.0)
        return Wg

def mechanism_adaptive_k(alpha, k_min=6, k_max=18):
    alpha_norm = torch.clamp(alpha / 90.0, 0.0, 1.0)
    k_i = (k_min + (k_max - k_min) * alpha_norm).round().int()
    return k_i

class MechanismGraphBuilder(nn.Module):
    """
    Orchestrates: PME + SPD + Gates + MMG (and optional Ma-k).
    """
    def __init__(self, use_pme=True, use_spd=True, spd_sigma=1.0, spd_lambda=0.5,
                 use_coherence_gate=True, coherence_beta=1.5,
                 use_esrg=False, esrg_a0=0.0, esrg_a1=1.0, esrg_a2=0.5,
                 k=12, mechanism_adaptive_k=False, build_bidirectional=True, device="cpu"):
        super().__init__()
        self.use_pme = use_pme
        self.use_spd = use_spd
        self.spd_sigma = spd_sigma
        self.spd_lambda = spd_lambda
        self.use_coherence_gate = use_coherence_gate
        self.coherence_beta = coherence_beta
        self.use_esrg = use_esrg
        self.k = k
        self.mechanism_adaptive_k = mechanism_adaptive_k
        self.build_bidirectional = build_bidirectional
        self.device = device

        self.pme = PMEEdge()
        self.esrg = ESRG(esrg_a0, esrg_a1, esrg_a2) if use_esrg else None

    def forward(self, H, A, alpha, C, Ps, Pd, Pv, gamma, span):
        """
        Returns:
            g_s, g_d, g_v: DGLGraph for surface/double/volume
            affinities: dict of dense W matrices for analysis (optional use)
        """
        # base PME
        if self.use_pme:
            W_pme = self.pme(H, A, alpha)
        else:
            W_pme = torch.zeros((H.size(0), H.size(0)), device=H.device)

        # SPD affinity
        if self.use_spd:
            W_spd = spd_log_euclidean_affinity(C, sigma=self.spd_sigma)
        else:
            W_spd = torch.zeros_like(W_pme)

        # convex fusion
        if self.use_pme and self.use_spd:
            W = self.spd_lambda * W_pme + (1.0 - self.spd_lambda) * W_spd
        else:
            W = W_pme + W_spd  # whichever nonzero

        # gates
        if self.use_coherence_gate:
            W = apply_coherence_gate(W, gamma, beta=self.coherence_beta)
        if self.use_esrg and self.esrg is not None:
            W = self.esrg(W, H, span)

        # mechanism masks
        Ms, Md, Mv = mechanism_masks(Ps, Pd, Pv)
        Ws = masked_affinity(W, Ms); Wd = masked_affinity(W, Md); Wv = masked_affinity(W, Mv)

        # k selection
        if self.mechanism_adaptive_k:
            k_i = mechanism_adaptive_k(alpha)
            k = int(max(2, int(k_i.float().mean().item())))
        else:
            k = self.k

        (e_s, w_s) = topk_edges_from_affinity(Ws, k, bidirectional=self.build_bidirectional)
        (e_d, w_d) = topk_edges_from_affinity(Wd, k, bidirectional=self.build_bidirectional)
        (e_v, w_v) = topk_edges_from_affinity(Wv, k, bidirectional=self.build_bidirectional)

        num_nodes = H.size(0)
        g_s = build_dgl_graph(e_s, w_s, num_nodes)
        g_d = build_dgl_graph(e_d, w_d, num_nodes)
        g_v = build_dgl_graph(e_v, w_v, num_nodes)

        return (g_s, g_d, g_v), dict(W=W, W_pme=W_pme, W_spd=W_spd, Ws=Ws, Wd=Wd, Wv=Wv)
