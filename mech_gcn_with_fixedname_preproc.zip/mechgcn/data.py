import os, numpy as np

def _load(path, name, required=True):
    fp = os.path.join(path, name + ".npy")
    if not os.path.exists(fp):
        if required:
            raise FileNotFoundError(f"Missing required file: {fp}")
        else:
            return None
    arr = np.load(fp, allow_pickle=False)
    return arr

def load_dataset(data_dir, need_esrg=False):
    """
    Loads required NumPy arrays from `data_dir`.

    Returns:
        data: dict with keys:
            X: [N,F] float32
            y: [N] int64 (labels, -1 for unlabeled optional)
            H, A, alpha: [N] float32
            C: [N,3,3] float32 SPD
            Ps, Pd, Pv: [N] float32
            gamma: [N] float32 in [0,1]
            span: [N] float32
            train_idx, val_idx, test_idx: 1D int64 arrays

    Optional:
        If `need_esrg=False`, `span` may be skipped (will fill with ones).
    """
    X      = _load(data_dir, "features").astype("float32")
    y      = _load(data_dir, "labels").astype("int64")
    H      = _load(data_dir, "H").astype("float32")
    A      = _load(data_dir, "A").astype("float32")
    alpha  = _load(data_dir, "alpha").astype("float32")
    C      = _load(data_dir, "C").astype("float32")
    Ps     = _load(data_dir, "Ps").astype("float32")
    Pd     = _load(data_dir, "Pd").astype("float32")
    Pv     = _load(data_dir, "Pv").astype("float32")
    gamma  = _load(data_dir, "gamma").astype("float32")
    span   = _load(data_dir, "span", required=need_esrg)
    if span is None:
        span = np.ones_like(H, dtype="float32")

    train_idx = _load(data_dir, "train_idx").astype("int64")
    val_idx   = _load(data_dir, "val_idx").astype("int64")
    test_idx  = _load(data_dir, "test_idx").astype("int64")

    return dict(
        X=X, y=y, H=H, A=A, alpha=alpha, C=C, Ps=Ps, Pd=Pd, Pv=Pv,
        gamma=gamma, span=span, train_idx=train_idx, val_idx=val_idx, test_idx=test_idx
    )
