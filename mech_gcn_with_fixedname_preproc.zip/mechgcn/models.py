import torch, torch.nn as nn, torch.nn.functional as F
import dgl

class SimpleRGCNLayer(nn.Module):
    def __init__(self, in_dim, out_dim, num_rels=3):
        super().__init__()
        self.weight = nn.Parameter(torch.Tensor(num_rels, in_dim, out_dim))
        nn.init.xavier_uniform_(self.weight)

    def forward(self, g_list, h):
        out = 0
        for r, g in enumerate(g_list):
            with g.local_scope():
                g.ndata['h'] = h
                Wh = h @ self.weight[r]
                g.ndata['Wh'] = Wh
                def mfunc(edges):
                    return {'m': edges.src['Wh'] * edges.data['w'].unsqueeze(1)}
                g.update_all(mfunc, dgl.function.sum('m', 'h_new'))
                out = out + g.ndata['h_new']
        return F.relu(out)

class SimpleRGCN(nn.Module):
    def __init__(self, in_dim, hidden_dim, num_classes):
        super().__init__()
        self.gcn1 = SimpleRGCNLayer(in_dim, hidden_dim, num_rels=3)
        self.gcn2 = SimpleRGCNLayer(hidden_dim, hidden_dim, num_rels=3)
        self.cls  = nn.Linear(hidden_dim, num_classes)

    def forward(self, g_list, x):
        h = self.gcn1(g_list, x)
        h = self.gcn2(g_list, h)
        logits = self.cls(h)
        return logits, h
